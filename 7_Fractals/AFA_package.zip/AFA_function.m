function [result1,p1_slope, intercept] = AFA_function(data,beg,final)
%% Description 
% AFA function based on Jianbo Gao's AFA functions accompanying Riley, M.
% A., Bonnette, S., Kuznetsov, N., Wallot, S., & Gao, J. (2012). A tutorial
% introduction to adaptive fractal analysis. Frontiers in physiology, 3,
% 371..

% Inputs: data - COP signal (if already looking more similar to a random
% walk, do not integrate)
% beg and final - are the boundaries for fitting the linear scaling
% relation in the AFA plot.

% Parameters:
% step size - spacing between the window sizes for calculating fluctuation
% function
% q - should be 2 for regular monofractal DFA. could be a range for
% multifractal signals
% order - order of the polynomial to fit to each window (e.g., 1 or 2).

%% Example:
% data = randn(1024,1);
% [result1,p1_slope, intercept] = AFA_function(integrate(data(:,1)),1,16);
% integrate is used because the data vector is white noise (an fGn process)
% 
% if the process under analysis is more like an fBm process, then the
% integration is not necessary. For example:
% [result1,p1_slope, intercept] = AFA_function(data(:,1),1,16);
% where data(:,1) is an fBm.

%% AFA parameters
step_size = .5;
q = 2;
order = 1;
    
%% Actual AFA calculations    
result1 = multi_detrending(data, step_size, q, order);
result1 = unique(result1','rows')';

%% Plot the results
figure
subplot(121)
plot(diff(data),'.-')
subplot(122)
plot(result1(1,:), result1(2,:),'o','linewidth',1,...
    'MarkerSize',7,'Linewidth',2,'color',[.5 .5 .5]);
set(gca,'fontsize',18,'FontName','Times')
xlabel('log_2{\itw}','fontsize',18,'FontName','Times');
ylabel('log_2 {\itF} ({\itw})','fontsize',18,'FontName','Times');
axis square
hold on
set(gcf,'Position',[153.800000000000,433,1249.60000000000,328.800000000000])
plot(result1(1,beg:final), result1(2,beg:final),'or','linewidth',1,...
    'MarkerSize',7,'Linewidth',2);

%     plot(result1(1,12:18), result1(2,12:18),'og','linewidth',1,...
%     'MarkerSize',7,'Linewidth',2);

% preliminary fittings
p1 = polyfit(result1(1,beg:final), result1(2,beg:final),1);
plot(result1(1,beg:final),polyval(p1,result1(1,beg:final)),'r')
p1_slope = p1(1);
intercept = p1(2);
    
% p2 = polyfit(result1(1,12:18), result1(2,12:18),1);
% plot(result1(1,12:18),polyval(p2,result1(1,12:18)),'g')
% p2_slope = p2(1);  

end